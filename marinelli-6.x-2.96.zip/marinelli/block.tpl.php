
 <div class="defaultblock">
    <h2><?php print $block->subject; ?></h2><!--block title-->
   <div class="blockcontent"><?php print $block->content; ?></div>
</div>