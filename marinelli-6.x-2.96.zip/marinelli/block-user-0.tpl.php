<?php /*this is the login block*/ ?>

 <div class="loginblock">
    <h2 class="login"><?php print $block->subject; ?></h2><!--block title-->
   <div class="blockcontent"><?php print $block->content; ?></div>
</div>